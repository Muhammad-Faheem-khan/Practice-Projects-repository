var arr = [1, 2, 3, 4, 5]
var arr1 = [6, 7, 8]

console.log(arr.concat(arr1))