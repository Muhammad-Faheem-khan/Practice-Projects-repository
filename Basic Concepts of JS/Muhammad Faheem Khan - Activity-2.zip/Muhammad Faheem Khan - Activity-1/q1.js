var arr = [1, 2, 3, 4, 5]

arr.push(6)
console.log(arr)