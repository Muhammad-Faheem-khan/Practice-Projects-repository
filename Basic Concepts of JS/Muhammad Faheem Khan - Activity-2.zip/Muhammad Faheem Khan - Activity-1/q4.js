var arr = [1, 2, 3, 4, 5]

arr1 = arr.slice(1,4)
console.log(arr1)